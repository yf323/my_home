#include <linux/gpio.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/of.h>
#include <linux/of_gpio.h>

void led_set_value(struct gpio_desc* desc, int status)
{
    gpiod_set_value(desc,status);
}

int leds_init(struct device_node* node, struct gpio_desc** desc, char** gpioname, int n)
{
    int i;
    for (i = 0; i < n; i++) {
        desc[i] = gpiod_get_from_of_node(node, gpioname[i], 0, GPIOD_OUT_LOW, NULL);
        if (IS_ERR(desc[i])) {
            printk("gpio operation error\n");
            return PTR_ERR(desc[i]);
        }
    }
    return 0;
}

int leds_deinit(struct gpio_desc** desc, int n)
{
    int i;
    for (i = 0; i < n; i++) {
        gpiod_set_value(desc[i], 0);
        gpiod_put(desc[i]);
    }
    return 0;
}