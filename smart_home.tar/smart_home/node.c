#include <linux/gpio.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/of.h>
#include <linux/of_gpio.h>
extern struct device_node *pnode, *inode, *lnode, *dnode;
int get_device_node(void)
{
    // pnode = of_find_compatible_node(NULL, NULL, "hqyj,myplatform");
    // if (pnode == NULL) {
    //     printk("get pnode error\n");
    //     return -EINVAL;
    // }
    
    pnode = of_find_node_by_path("/my_home");
    if (pnode == NULL) {
        printk("get pnode error\n");
        return -1;
    }

    inode = of_get_child_by_name(pnode, "my_home_irq");
    if (inode == NULL) {
        printk("get inode error\n");
        return -EINVAL;
    }

    lnode = of_get_child_by_name(pnode, "my_home_led");
    if (lnode == NULL) {
        printk("get lnode error\n");
        return -EINVAL;
    }
    dnode = of_get_child_by_name(pnode, "my_home_dev");
    if (dnode == NULL) {
        printk("get dnode error\n");
        return -EINVAL;
    }
    return 0;
}