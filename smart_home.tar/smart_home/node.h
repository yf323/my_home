#ifndef __NODE_H__
#define __NODE_H__
int get_device_node(void);
#endif