#ifndef __CDEV_H__
#define __CDEV_H__
int init_cdev(void);
void deinit_cdev(void);
#endif