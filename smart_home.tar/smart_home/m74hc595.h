#ifndef __M74HC595_H__
#define __M74HC595_H__

#define SEG_WHICH _IOW('k',0,int)
#define SEG_DAT  _IOW('k',1,int)
#endif