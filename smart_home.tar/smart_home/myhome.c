#include <linux/gpio.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/of.h>
#include <linux/of_gpio.h>

#include <linux/of_irq.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/poll.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include "node.h"
#include "cmd.h"
#include "dive.h"
#include "cdev.h"

#define IRQNAME "key_irq"
unsigned int irqno[3];
int gpiono[3];
const char* irqname[] = { "key1", "key2", "key3" };
int status=0;

struct timer_list mytimer;
/*
my_home{                                                                          
    compatible = "hqyj,myplatform";
    my_home_irq{
        interrupt-parent = <&gpiof>;  //指定中断的父节点
        interrupts=<9 0>,<7 0>,<8 0>;   //9中断的index号，0中断的触发方式（默认）
        key_gpio = <&gpiof 9 0>,<&gpiof 7 0>,<&gpiof 8 0>;
    };
    my_home_led{
        gpio1 = <&gpioe 10 0>;  //10:gpioe10   0默认状态
        gpio2 = <&gpiof 10 0>;  //10:gpiof10   0默认状态
        gpio3 = <&gpioe 8 0>;   //8:gpioe8   0默认状态  
    };
    my_home_dev{
        gpio1 = <&gpioe 9 0>;
        gpio2 = <&gpiob 6 0>;
        gpio3 = <&gpiof 6 0>;
    };
};
*/

struct device_node *pnode, *inode, *lnode, *dnode;
struct gpio_desc* ldesc[3];
struct gpio_desc* ddesc[3];

char* gpioname[3] = { "gpio1", "gpio2", "gpio3" };

void timer_handle(struct timer_list* timer)
{
    if (gpio_get_value(gpiono[0]) == 0) {
        status+=1;
        gpiod_set_value(ldesc[0],!gpiod_get_value(ldesc[0]));
        printk("status=%d\n",status);
    }
    if (gpio_get_value(gpiono[1]) == 0) {
        status+=1;
        gpiod_set_value(ldesc[1],!gpiod_get_value(ldesc[1]));
        printk("status=%d\n",status);   
    }
    if (gpio_get_value(gpiono[2]) == 0) {
        status+=1;
        gpiod_set_value(ldesc[2],!gpiod_get_value(ldesc[2]));
        printk("status=%d\n",status);
    }
}
irqreturn_t key_irq_handle(int irq, void* dev)
{
    //启动定时器
    mod_timer(&mytimer, jiffies + 1);
    return IRQ_HANDLED;
}
int gpio_leds_open(struct inode* inode, struct file* file)
{
    printk("%s:%d\n", __func__, __LINE__);
    return 0;
}
long gpio_leds_ioctl(struct file* file,
    unsigned int cmd, unsigned long args)
{
    int which, ret;

    ret = copy_from_user(&which, (void*)args, sizeof(int));
    if (ret) {
        printk("copy data from user error\n");
        return -EINVAL;
    }
/*
void led_set_value(struct gpio_desc* desc, int status)
{
    gpiod_set_value(desc,status);
}
*/
    switch (cmd) {
    case LED_ON:
        led_set_value(ldesc[which],1);
        break;
    case LED_OFF:
        led_set_value(ldesc[which],0);
        break;
    case divice_ON:
        led_set_value(ddesc[which],1);
        break;
    case divice_OFF:
        led_set_value(ddesc[which],0);
        break;
    }

    return 0;
}
int gpio_leds_close(struct inode* inode, struct file* file)
{
    printk("%s:%d\n", __func__, __LINE__);
    status=0;
    return 0;
}
struct file_operations fops = {
    .open = gpio_leds_open,
    .unlocked_ioctl = gpio_leds_ioctl,
    .release = gpio_leds_close,
};



static int __init mycdev_init(void)
{
    int ret,i;
    //0.初始化定时器
    mytimer.expires = jiffies + 1;
    timer_setup(&mytimer, timer_handle, 0);
    add_timer(&mytimer);

    // 1.解析节点
    if (get_device_node()) {
        printk("parse device node error\n");
        return -EINVAL;
    }
    // 2.led的初始化
    leds_init(lnode, ldesc, gpioname, ARRAY_SIZE(ldesc));
    leds_init(dnode, ddesc, gpioname, ARRAY_SIZE(ddesc));

    // 3.注册字符设备驱动创建
    if ((ret = init_cdev()) < 0) {
        printk("cdev create error\n");
        return ret;
    }
    // 4，中断创建   
    for (i = 0; i < ARRAY_SIZE(irqno); i++)
    {   // 1.获取gpio号
        gpiono[i] = of_get_named_gpio(inode, "key_gpio", i);
        if (gpiono[i] < 0) {
            printk("get gpio number error\n");
            return gpiono[i];
        }
        // 2.映射软中断号
        irqno[i] = irq_of_parse_and_map(inode,i);
        if(!irqno[i]){
            printk("get irq number error\n");
            return -EAGAIN;
        }
    
    // 4.注册中断
        ret = request_irq(irqno[i], key_irq_handle,
            IRQF_TRIGGER_FALLING, irqname[i], (void*)i);
        if (ret) {
            printk("request irq error\n");
            return ret;
        }
    }      
    return 0;
}
static void __exit mycdev_exit(void)
{
    int i;
    deinit_cdev();
    leds_deinit(ldesc, ARRAY_SIZE(ldesc));
    leds_deinit(ddesc, ARRAY_SIZE(ddesc));
   
    for (i = 0; i < ARRAY_SIZE(irqno); i++) {
        free_irq(irqno[i], (void*)i);
        gpiod_put(ldesc[i]);
    }
    del_timer(&mytimer);
}
module_init(mycdev_init);
module_exit(mycdev_exit);
MODULE_LICENSE("GPL");