#ifndef __DIVE_H__
#define __DIVE_H__
void led_set_value(struct gpio_desc* desc, int status);
int leds_init(struct device_node* node, struct gpio_desc** desc, char** gpioname, int n);
int leds_deinit(struct gpio_desc** desc, int n);
#endif