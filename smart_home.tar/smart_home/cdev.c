#include <linux/gpio.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/of.h>
#include <linux/of_gpio.h>

#define CNAME "my_home"
int major;
struct class* cls;
struct device* dev;
extern struct file_operations fops;
int init_cdev(void)
{
    major = register_chrdev(0, CNAME, &fops);
    if (major <= 0) {
        printk("register chardev error\n");
        return -EAGAIN;
    }
    // 4.创建设备节点
    cls = class_create(THIS_MODULE, CNAME);
    if (IS_ERR(cls)) {
        printk("class create error\n");
        return PTR_ERR(cls);
    }
    dev = device_create(cls, NULL, MKDEV(major, 0), NULL, CNAME);
    if (IS_ERR(dev)) {
        printk("device create error\n");
        return PTR_ERR(dev);
    }
    return 0;
}
void deinit_cdev(void)
{
    device_destroy(cls, MKDEV(major, 0));
    class_destroy(cls);
    unregister_chrdev(major, CNAME);
}