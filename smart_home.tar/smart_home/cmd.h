#ifndef __CMD_H__
#define __CMD_H__

#define LED_ON  _IOW('k',0,int)
#define LED_OFF _IOW('k',1,int)
#define divice_ON  _IOW('k',2,int)
#define divice_OFF _IOW('k',3,int)
#endif