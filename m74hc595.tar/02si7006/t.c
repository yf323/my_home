#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include "si7006.h"
#include "m74hc595.h"

int main(int argc, char const *argv[])
{
    int fd1,fd2;
    int r, htum,i;
    float rtmp, rhum;
    int thm[2]={0};

    int ytmp[4]={0};
	int yhum[4]={0};
    if ((fd1 = open("/dev/si7006", O_RDWR)) == -1)
    {
        printf("open error\n");
        return -1;
    }
    fd2 = open("/dev/m74hc595",O_RDWR);
    if(fd2 < 0){
		perror("open error");
    return -1;
	}

    while (1) {
        ioctl(fd1, GET_SI7006_TMP, &r);
        ioctl(fd1, GET_SI7006_HUM, &htum);

        rtmp = 175.72 * r / 65536 - 46.85;
        rhum = 125 * htum / 65536 - 6;

        //把温湿度的值写入到数码管上
        thm[0]=rtmp*10;
        thm[1]=rhum*10;

        ytmp[0]=thm[0]/100;
    	ytmp[1]=(thm[0]-ytmp[0]*100)/10;
    	ytmp[2]=thm[0]%10;
    	ytmp[3]=10;

    	yhum[0]=thm[1]/100;
    	yhum[1]=(thm[1]-yhum[0]*100)/10;
    	yhum[2]=thm[1]%10;
    	yhum[3]=11;

        for(i=0;i<4;i++)
        {
            printf("%d\n",ytmp[i]);
            write(fd2,&ytmp[i],sizeof(ytmp));
            sleep(0.4);
        }
        
        //write(fd2,thm,sizeof(thm));
        
        printf("r = %.2f,htum=%.2f\n", rtmp, rhum);
        
    }
    close(fd1);
    close(fd2);
    return 0;
}
                                                                                    
