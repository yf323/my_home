#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include "si7006.h"
#include "m74hc595.h"

void do_led();    // led菜单
void do_fan();    //风扇
void do_buzzer(); //蜂鸣器
void do_motor();  //马达
void do_tah(int fd1,int fd2);    //温湿度传感器

void do_tem(int fd1,int fd2);
void do_hum(int fd1,int fd2);

int main(int argc, char const *argv[])
{
    int fd1,fd2;
    if ((fd1 = open("/dev/si7006", O_RDWR)) == -1)
    {
        printf("open error\n");
        return -1;
    }
    fd2 = open("/dev/m74hc595",O_RDWR);
    if(fd2 < 0){
		perror("open error");
    return -1;
	}
    int function_hoice = 0; //功能选择
    while (1)
    {
        if (function_hoice == 6)
        {
            break;
        }
        printf("**********************************************************\n");
        printf("1.led灯 2.风扇 3.蜂鸣器 4.马达  5.温湿度传感器 6.退出功能菜单\n");
        printf("**********************************************************\n");
        printf("请选择>>");

        scanf("%d", &function_hoice);

        switch (function_hoice)
        {
        case 1:
            do_led(); // led
            break;
        case 2:
            do_fan(); //风扇
            break;
        case 3:
            do_buzzer(); //蜂鸣器
            break;
        case 4:
            do_motor(); //马达
            break;
        case 5:
            do_tah(fd1,fd2); //温湿度传感器
            break;
        case 6:
            break; //退出
        }
    }
    return 0;
}
void do_led()
{
    int led_hoice;
    while (1)
    {
        if (led_hoice == 3)
        {
            break;
        }
        printf("1.灯开 2.灯关 3.返回上一级:");
        scanf("%d", &led_hoice);
        switch (led_hoice)
        {
        case 1:
            printf("灯开\n"); //开
            break;
        case 2:
            printf("灯关\n"); //关
            break;
        case 3:
            break;
        default:
            break;
        }
    }
}
void do_fan()
{
    int a = 0;
    while (1)
    {
        if (a == 3)
        {
            break;
        }
        printf("1.风扇开 2.风扇关 3.返回上一级:");
        scanf("%d", &a);
        switch (a)
        {
        case 1:
            printf("风扇开\n");
            break;
        case 2:
            printf("风扇关\n");
            break;
        case 3:
            break;
        default:
            break;
        }
    }
}
void do_buzzer()
{
    int a = 0;
    while (1)
    {
        if (a == 3)
        {
            break;
        }
        printf("1.蜂鸣器开 2.蜂鸣器关 3.返回上一级:");
        scanf("%d", &a);
        switch (a)
        {
        case 1:
            printf("蜂鸣器开\n");
            break;
        case 2:
            printf("蜂鸣器关\n");
            break;
        case 3:
            break;
        default:
            break;
        }
    }
}
void do_motor()
{
    int a = 0;
    while (1)
    {
        if (a == 3)
        {
            break;
        }
        printf("1.马达开 2.马达关 3.返回上一级:");
        scanf("%d", &a);
        switch (a)
        {
        case 1:
            printf("马达开\n");
            break;
        case 2:
            printf("马达关\n");
            break;
        case 3:
            break;
        default:
            break;
        }
    }
}
void do_tah(int fd1,int fd2)
{
    int a = 0;

    while (1)
    {
        if (a == 3)
        {
            break;
        }
        printf("1.温度 2.湿度 3.返回上一级:");
        scanf("%d", &a);
        switch (a)
        {
        case 1:
            do_tem(fd1,fd2);
            printf("温度\n");
            break;
        case 2:
            do_hum(fd1,fd2);
            printf("湿度\n");
            break;
        case 3:
            break;
        default:
            break;
        }
    }
}
void do_tem(int fd1,int fd2)
{
    int r, htum,i,j,k;
    float rtmp, rhum;
    int thm[2]={0};

    int ytmp[4]={0};
	int yhum[4]={0};
    for(j=0;j<100;j++)
    {       
        ioctl(fd1, GET_SI7006_TMP, &r);
        ioctl(fd1, GET_SI7006_HUM, &htum);

        rtmp = 175.72 * r / 65536 - 46.85;
        rhum = 125 * htum / 65536 - 6;
        if(j<1)
        {
            printf("r = %.2f,htum=%.2f\n", rtmp, rhum);
        }
        

        //把温湿度的值写入到数码管上
        thm[0]=rtmp*10;
        thm[1]=rhum*10;

        ytmp[0]=thm[0]/100;
    	ytmp[1]=(thm[0]-ytmp[0]*100)/10;
    	ytmp[2]=thm[0]%10;
    	ytmp[3]=10;

    	// yhum[0]=thm[1]/100;
    	// yhum[1]=(thm[1]-yhum[0]*100)/10;
    	// yhum[2]=thm[1]%10;
    	// yhum[3]=11;
        
            for(k=0;k<100;k++)
            {
                for(i=0;i<4;i++)
                {
                    write(fd2,&ytmp[i],sizeof(ytmp));
                    sleep(0.4);
                }
            } 
        }    
}
void do_hum(int fd1,int fd2)
{
    int r, htum,i,j,k;
    float rtmp, rhum;
    int thm[2]={0};

    int ytmp[4]={0};
	int yhum[4]={0};
    for(j=0;j<150;j++)
    {       
        ioctl(fd1, GET_SI7006_TMP, &r);
        ioctl(fd1, GET_SI7006_HUM, &htum);

        rtmp = 175.72 * r / 65536 - 46.85;
        rhum = 125 * htum / 65536 - 6;

        if(j<1)
        {
            printf("r = %.2f,htum=%.2f\n", rtmp, rhum);
        }
        //把温湿度的值写入到数码管上
        thm[0]=rtmp*10;
        thm[1]=rhum*10;

        // ytmp[0]=thm[0]/100;
    	// ytmp[1]=(thm[0]-ytmp[0]*100)/10;
    	// ytmp[2]=thm[0]%10;
    	// ytmp[3]=10;

    	yhum[0]=thm[1]/100;
    	yhum[1]=(thm[1]-yhum[0]*100)/10;
    	yhum[2]=thm[1]%10;
    	yhum[3]=11;
        
            for(k=0;k<100;k++)
            {
                for(i=0;i<4;i++)
                {
                    write(fd2,&yhum[i],sizeof(yhum));
                    sleep(0.4);
                }
            }
             
        }              
}

