#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include "si7006.h"

int main(int argc, const char* argv[])
{
    int fd;
    int tmp, hum;
    float rtmp, rhum;
    if ((fd = open("/dev/si7006", O_RDWR)) == -1)
    {
        printf("open error\n");
        return -1;
    }
    while (1) {
        ioctl(fd, GET_SI7006_TMP, &tmp);
        ioctl(fd, GET_SI7006_HUM, &hum);

        rtmp = 175.72 * tmp / 65536 - 46.85;
        rhum = 125 * hum / 65536 - 6;

        printf("tmp = %.2f,hum=%.2f\n", rtmp, rhum);
        sleep(1);
    }
    close(fd);
    return 0;
}