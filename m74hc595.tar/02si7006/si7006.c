#include <linux/i2c.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include "si7006.h"
#define CNAME "si7006"
struct i2c_client* gclient;
int major = 0;
struct class* cls;
struct device* dev;



int i2c_read_serial_firmware(unsigned short reg)
{
    int ret;
    unsigned char r_buf[] = { (reg >> 8 & 0xff), (reg & 0xff) };
    unsigned char data;
    // 1.封装消息
    struct i2c_msg r_msg[] = {
        [0] = {
            .addr = gclient->addr,
            .flags = 0,
            .len = 2,
            .buf = r_buf,
        },
        [1] = {
            .addr = gclient->addr,
            .flags = 1,
            .len = 1,
            .buf =&data,
        },
    };
    // 2发送消息
    ret = i2c_transfer(gclient->adapter, r_msg, ARRAY_SIZE(r_msg));
    if (ret != ARRAY_SIZE(r_msg)) {
        printk("i2c read serial or firmware error\n");
        return -EAGAIN;
    }

    return data;
}
int i2c_read_tmp_hum(unsigned char reg)
{
    int ret;
    unsigned char r_buf[] = { reg };
    unsigned short data;
    // 1.封装消息
    struct i2c_msg r_msg[] = {
        [0] = {
            .addr = gclient->addr,
            .flags = 0,
            .len = 1,
            .buf = r_buf,
        },
        [1] = {
            .addr = gclient->addr,
            .flags = 1,
            .len = 2,
            .buf =  (__u8 *)&data,
        },
    };
    // 2发送消息
    ret = i2c_transfer(gclient->adapter, r_msg, ARRAY_SIZE(r_msg));
    if (ret != ARRAY_SIZE(r_msg)) {
        printk("i2c read serial or firmware error\n");
        return -EAGAIN;
    }
    data = data >> 8 | data << 8;
    return data;
}

int si7006_open(struct inode* inode, struct file* file)
{
    printk("%s:%d\n", __func__, __LINE__);
    return 0;
}
long si7006_ioctl(struct file* file,
    unsigned int cmd, unsigned long args)
{
    int ret,data;
    switch (cmd) {
    case GET_SI7006_TMP:
        data = i2c_read_tmp_hum(TMP_ADDR);
        ret = copy_to_user((void *)args,&data,GET_CMD_SIZE(GET_SI7006_TMP));
        if(ret){
            printk("copy data to user error\n");
            return -EIO;
        }

        break;
    case GET_SI7006_HUM:
        data = i2c_read_tmp_hum(HUM_ADDR);
        ret = copy_to_user((void *)args,&data,GET_CMD_SIZE(GET_SI7006_HUM));
        if(ret){
            printk("copy data to user error\n");
            return -EIO;
        }
        break;

    }

    return 0;
}

int si7006_close(struct inode* inode, struct file* file)
{
    printk("%s:%d\n", __func__, __LINE__);
    return 0;
}
struct file_operations fops = {
    .open = si7006_open,
    .unlocked_ioctl = si7006_ioctl,   
    .release = si7006_close,
};

int si7006_probe(struct i2c_client* client, const struct i2c_device_id* id)
{
    int ret;
    gclient = client;
    printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);

    ret = i2c_read_serial_firmware(0xfcc9);
    printk("serial(0x06) = %#x\n", ret);

    ret = i2c_read_serial_firmware(0x84b8);
    printk("firmware(0xff or 0x20) = %#x\n", ret);

    major = register_chrdev(0, CNAME, &fops);
    if (major <= 0) {
        printk("register char device driver error\n");
        return -EAGAIN;
    }
    cls = class_create(THIS_MODULE, CNAME);
    if (IS_ERR(cls)) {
        printk("class create error\n");
        return PTR_ERR(cls);
    }
    dev = device_create(cls, NULL, MKDEV(major, 0), NULL, CNAME);
    if (IS_ERR(dev)) {
        printk("device create error\n");
        return PTR_ERR(dev);
    }
    return 0;
}
int si7006_remove(struct i2c_client* client)
{
    printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
    device_destroy(cls,MKDEV(major,0));
    class_destroy(cls);
    unregister_chrdev(major,CNAME);
    return 0;
}
const struct of_device_id oftable[] = {
    {
        .compatible = "hqyj,si7006",
    },
    { /*end*/ }
};
MODULE_DEVICE_TABLE(of, oftable);

struct i2c_driver si7006 = {
    .probe = si7006_probe,
    .remove = si7006_remove,
    .driver = {
        .name = "heihei",
        .of_match_table = oftable,
    }
};
module_i2c_driver(si7006);
MODULE_LICENSE("GPL");